API_URL = "http://192.168.10.90:5000/api/extaxis"
# API_URL = "http://localhost:5000/api/extaxis"

LUMI_ENABLE_URL = API_URL + "/enable"
LUMI_RESET_URL = API_URL + "/reset"
LUMI_MOVETO_URL = API_URL + "/moveto"
LUMI_STATUS_URL = API_URL + "/status"
LUMI_SYSINFO_URL = API_URL + "/sysinfo"
LUMI_GETSTATE_URL = API_URL + "/status"